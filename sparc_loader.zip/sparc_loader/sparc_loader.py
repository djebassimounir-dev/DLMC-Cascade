"""
sparc_loader.py -- Robust loader for SPARC Rotmod_LTG rotation-curve files.

Background
----------
The standard SPARC "*_rotmod.dat" file format (Lelli, McGaugh & Schombert
2016, AJ 152, 157) has EIGHT whitespace-separated columns per row:

    Rad   Vobs   errV   Vgas   Vdisk   Vbul   SBdisk   SBbul
    kpc   km/s   km/s   km/s   km/s    km/s   L/pc^2   L/pc^2

A common mistake when loading these files is to call
`pandas.read_csv(..., names=[...6 names...])` with only six column names.
When the actual row has eight fields and `names` supplies only six, pandas
treats the two left-most columns as an implicit index rather than raising
an error. The result: `Vdisk` silently receives the values that actually
belong to `SBdisk` (surface brightness, in L/pc^2, not a velocity), and
`Vbulge` receives `SBbul`. Since surface brightness values can be in the
hundreds or low thousands for bright galaxies, this produces velocity
columns with physically impossible values (e.g. "Vdisk" > 5000 km/s) that
are easy to miss unless you specifically check the ranges.

This loader reads all columns explicitly by position and works whether the
file has six or eight columns.

Note on Vgas sign: `Vgas` can be legitimately negative at small radii. This
is a documented SPARC convention (sign-preserving quadrature, reflecting
pressure-dominated inner regions), not a data defect -- do not "fix" it.
"""

import os
import numpy as np
import pandas as pd

SPARC_COLUMNS_8 = ["R", "Vobs", "errV", "Vgas", "Vdisk", "Vbulge", "SBdisk", "SBbul"]
SPARC_COLUMNS_6 = ["R", "Vobs", "errV", "Vgas", "Vdisk", "Vbulge"]


def load_rotmod(filepath: str) -> pd.DataFrame:
    """Load one SPARC *_rotmod.dat file, auto-detecting 6- vs 8-column format.

    Returns a DataFrame with at least the columns:
        R, Vobs, errV, Vgas, Vdisk, Vbulge
    and, when present in the file, SBdisk, SBbul.

    Raises ValueError if the file does not have 6 or 8 numeric columns.
    """
    # Peek at the first non-comment line to count columns before committing
    # to a column-name scheme.
    n_cols = None
    with open(filepath, "r", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            n_cols = len(line.replace(",", " ").split())
            break

    if n_cols is None:
        raise ValueError(f"No data rows found in {filepath}")

    if n_cols == 8:
        names = SPARC_COLUMNS_8
    elif n_cols == 6:
        names = SPARC_COLUMNS_6
    else:
        raise ValueError(
            f"{filepath}: expected 6 or 8 columns, found {n_cols}. "
            f"Inspect this file manually before using it."
        )

    df = pd.read_csv(
        filepath,
        comment="#",
        sep=r"\s+",
        header=None,
        names=names,
    )

    # Sanity check: catch the exact failure mode this loader exists to avoid.
    # Stellar/gas rotation velocities in SPARC do not exceed a few hundred km/s.
    for col in ("Vdisk", "Vbulge"):
        if col in df.columns and df[col].abs().max() > 1000:
            raise ValueError(
                f"{filepath}: {col} has values above 1000 (km/s expected). "
                f"This usually means column misalignment -- re-check n_cols "
                f"detection for this file rather than trusting this output."
            )

    return df


def load_catalogue(directory: str) -> dict:
    """Load every *_rotmod.dat file in `directory`.

    Returns a dict {filename: DataFrame}. Files that fail to load (wrong
    column count, sanity check failure) are reported to stderr and skipped,
    not silently dropped.
    """
    import glob
    import sys

    catalogue = {}
    for filepath in sorted(glob.glob(os.path.join(directory, "*_rotmod.dat"))):
        name = os.path.basename(filepath)
        try:
            catalogue[name] = load_rotmod(filepath)
        except ValueError as e:
            print(f"[SKIPPED] {name}: {e}", file=sys.stderr)

    return catalogue


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Usage: python sparc_loader.py <path_to_rotmod_directory>")
        sys.exit(1)

    cat = load_catalogue(sys.argv[1])
    print(f"Loaded {len(cat)} galaxies successfully.")
    for name, df in list(cat.items())[:3]:
        print(f"\n{name}:")
        print(df.describe())
