# A Column-Alignment Pitfall in SPARC Rotmod_LTG Files

**Author:** Djebassi Mounir ([ORCID: 0009-0009-6871-7693](https://orcid.org/0009-0009-6871-7693))
**License:** CC-BY 4.0 (documentation), MIT (code)

## What this is

A short technical note and a corrected loader function, documenting a
parsing pitfall encountered while working with the SPARC (Spitzer
Photometry and Accurate Rotation Curves) database of Lelli, McGaugh &
Schombert (2016, AJ 152, 157) during independent rotation-curve modeling
work. This is **not** a claim of an error in the SPARC data itself — the
data are correct. It is a note on a parsing mistake that is easy to make
when writing a loader from scratch, aimed at saving other newcomers to the
catalogue the same debugging detour.

## The pitfall

The standard `*_rotmod.dat` file in the `Rotmod_LTG` distribution has
**eight** whitespace-separated columns per data row:

```
# Rad   Vobs   errV   Vgas   Vdisk   Vbul   SBdisk   SBbul
# kpc   km/s   km/s   km/s   km/s    km/s   L/pc^2   L/pc^2
```

A natural first loader, written from memory of the six physically obvious
quantities (radius, observed velocity, error, gas/disk/bulge velocity),
looks like this:

```python
df = pd.read_csv(filepath, comment="#", sep=r"\s+", header=None,
                  names=["R", "Vobs", "errV", "Vgas", "Vdisk", "Vbulge"])
```

This runs without error and returns a DataFrame — which is exactly what
makes the mistake dangerous. When `names` has fewer entries than the
number of columns actually present, pandas does not raise an error; it
treats the left-most extra column(s) as an implicit index and shifts the
given names onto the *right-most* columns of the data. Concretely, with 8
data columns and 6 names, the result is:

| Given name | Column it actually receives |
|---|---|
| `R` | `errV` |
| `Vobs` | `Vgas` |
| `errV` | `Vdisk` |
| `Vgas` | `Vbul` |
| `Vdisk` | `SBdisk` |
| `Vbulge` | `SBbul` |

`SBdisk` and `SBbul` are **surface brightness** values (L/pc²), not
velocities, and routinely reach the hundreds or low thousands for bright
galaxies. Loaded as if they were `Vdisk`/`Vbulge`, they produce disk/bulge
"velocities" of several thousand km/s — physically impossible for a
galaxy rotation curve, but not so absurd-looking (a large number in a
velocity column) that it is guaranteed to be caught on casual inspection,
especially once downstream computations (ratios, corrections, fitted
models) obscure the original column.

## Not a defect: the sign of `Vgas`

While investigating this, we also encountered rows where `Vgas` is
negative at small radii. This is **not** a data error — it is a documented
SPARC convention (sign-preserving quadrature), reflecting radii where
thermal/pressure support dominates over rotation. A loader should preserve
this sign, not "correct" it.

## The fix

`sparc_loader.py` in this repository:
- detects the actual column count of each file before assigning names
  (6-column and 8-column variants both handled),
- includes a sanity check that flags (rather than silently accepting)
  disk/bulge "velocities" above 1000 km/s, which is the direct symptom of
  this misalignment,
- reports skipped/failed files explicitly instead of dropping them
  silently from a catalogue-wide loop.

## Usage

```bash
python sparc_loader.py /path/to/Rotmod_LTG/
```

or as a library:

```python
from sparc_loader import load_rotmod, load_catalogue

df = load_rotmod("NGC0100_rotmod.dat")
catalogue = load_catalogue("/path/to/Rotmod_LTG/")
```

## Scope and limitations of this note

This was found while loading a subset of the catalogue during unrelated
modeling work, not from a systematic audit of all 175 galaxy files. The
8-column format appears to be the standard `Rotmod_LTG` distribution
format based on the public GitHub mirror consulted; if a given local copy
of the catalogue uses a different convention, the column-count detection
in `sparc_loader.py` will report it explicitly rather than fail silently.

## Acknowledgment

This note exists only because of the SPARC database itself — a resource
built from decades of radio-astronomy observations by Federico Lelli,
Stacy McGaugh, Jim Schombert, and the wider community. The intent here is
purely to save fellow newcomers a debugging detour, not to critique the
catalogue.
