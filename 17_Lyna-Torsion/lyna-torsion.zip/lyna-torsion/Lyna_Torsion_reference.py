#!/usr/bin/env python
# coding: utf-8

# # Lyna Ψ-Torsion — Reference Implementation 
# 
# **Author:** Djebassi Mounir
# **Companion notebook to:** *"Lyna Ψ-Torsion: An Exploratory Heuristic Coupling Between Geometric Torsion, the Fine-Structure Constant, and Hydrodynamic Dissipation in Turbulent Stellar Media"* (revised version, June 2026)
# 
# This notebook reproduces **only** the single static evaluation reported in Section 4 of the revised paper.
# 
# It deliberately **does not include**:
# - the multi-epoch "temporal evolution" tables from the original draft (they were computed from manually-set constants disconnected from the Gaia-derived value below — see paper Section 7, *Limitations*);
# - the magnetic-field calibration section (relied on an undocumented scale factor `facteur_echelle = 1.8e29` with no derivation);
# - the `bruit_fond` noise term from the original notebook (arbitrary, unjustified, not tied to any measurement uncertainty model).
# 
# If you want a genuine iterative recurrence (Ψₙ → Ψₙ₊₁ over real steps), see the TODO cell at the end. It is **not implemented**. Do not fill it with an arbitrary formula just to produce numbers — the coupling from one step to the next must be derived and justified first.

# In[10]:


import os
import sys

import numpy as np
import pandas as pd


# ## 1. Data loading

# In[11]:


DATA_PATH = "gaia_data.csv"

def load_data(path: str = DATA_PATH):
    """Load the Gaia extract (ra, dec, parallax columns expected).

    Falls back to a small synthetic placeholder dataset if the real file is
    not found, so the notebook can be run and inspected end-to-end. The
    synthetic fallback is clearly flagged -- never draw conclusions from it.
    """
    if os.path.exists(path):
        df = pd.read_csv(path)
        source = f"loaded from '{path}'"
    else:
        print(f"[WARNING] '{path}' not found. Using a small SYNTHETIC placeholder "
              f"dataset so the notebook can run end-to-end. Replace with your real "
              f"Gaia extract before drawing any conclusion from the output below.",
              file=sys.stderr)
        rng = np.random.default_rng(42)
        n = 89
        df = pd.DataFrame({
            "ra": np.sort(rng.uniform(44.9, 45.1, n)),
            "dec": rng.uniform(35.25, 35.35, n),
            "parallax": rng.normal(0.5, 0.6, n),
        })
        source = "SYNTHETIC placeholder (no real gaia_data.csv found)"
    return df, source

df, source = load_data()
df.columns = [c.lower() for c in df.columns]

required_cols = {"ra", "dec", "parallax"}
missing = required_cols - set(df.columns)
if missing:
    raise ValueError(f"Missing required columns: {missing}. Expected: {required_cols}")

df_clean = df.dropna(subset=["ra", "dec", "parallax"]).reset_index(drop=True)
df_clean = df_clean.sort_values("ra").reset_index(drop=True)
n = len(df_clean)

print(f"Data source: {source}")
print(f"N = {n} valid sources after cleaning (report this N consistently throughout the paper).")
df_clean.head()


# ## 2. Constants — declared as free parameters, NOT derived (see paper Section 7)

# In[12]:


ALPHA = 1 / 137.036   # fine-structure constant, used as a fixed normalization
H_PARAM = np.pi / 9   # free parameter -- not derived from a physical boundary
OMEGA = 1e-3          # angular frequency of the phase term e^{-i*Omega*t}
EPSILON = 1e-6        # Tikhonov-style regularizer, avoids division by ~0
T_EVAL = 1.0          # static evaluation "time" (arbitrary units, not a real epoch)


# ## 3. Discrete torsion integral

# In[13]:


def torsion_integral(df, alpha=ALPHA, omega=OMEGA, epsilon=EPSILON, t=T_EVAL):
    """Discrete approximation of oint_tau (alpha * grad_u * e^{-i*Omega*t}) d_tau.

    `grad_u` is approximated from consecutive parallax differences, used here
    as a proxy for a velocity gradient -- an analogy of convenience, not a
    physically derived correspondence (see paper Sections 3.1 and 7).
    """
    ra = df["ra"].to_numpy()
    dec = df["dec"].to_numpy()
    parallax = df["parallax"].to_numpy()

    phase = np.exp(-1j * omega * t)
    total = 0.0 + 0.0j

    for k in range(len(df) - 1):
        du_k = np.sqrt((ra[k + 1] - ra[k]) ** 2 + (dec[k + 1] - dec[k]) ** 2)
        grad_u = (parallax[k + 1] - parallax[k]) / (du_k + epsilon)
        total += alpha * grad_u * phase * du_k

    return total


# ## 4. Saturation operator Φ(S)

# In[14]:


def saturation_phi(df):
    s_value = (df["ra"].max() - df["ra"].min()) * (df["dec"].max() - df["dec"].min())
    phi = 1.0 / (1.0 + np.exp(-s_value))
    return phi, s_value


# ## 5. Dissipation term B(H)

# In[15]:


def dissipation_B(h=H_PARAM):
    return np.sin(h) + 1j * np.cos(h)


# ## 6. Single static evaluation of Ψ_L (mirrors paper Section 4)

# In[16]:


integral_value = torsion_integral(df_clean)
phi_s, s_value = saturation_phi(df_clean)
b_h = dissipation_B()
psi_l = phi_s * integral_value - b_h

print(f"--- Static evaluation of Psi_L (t = {T_EVAL:.1f}, arbitrary units) ---")
print(f"S                = {s_value:.6f}")
print(f"Phi(S)           = {phi_s:.6e}")
print(f"Torsion integral = {integral_value:.6e}")
print(f"B(H), H = pi/9   = {b_h:.6e}")
print(f"Psi_L (real)     = {psi_l.real:.6e}")
print(f"Psi_L (imag)     = {psi_l.imag:.6e}")


# > **NOTE:** this is a single static evaluation, **not** a time evolution. No claim of convergence, regularity, or physical validation follows from this number alone. See paper Section 7, *Limitations*.

# ## 7. TODO — genuine iterative recurrence (NOT implemented, NOT validated)

# In[17]:


# A real test of the recurrence hypothesis in Section 2 of the paper would
# require feeding Psi_n back into the computation of Psi_{n+1} over
# successive steps, e.g.:
#
#   psi = psi_l  # seed from the real, data-derived value above
#   history = [psi]
#   for step in range(n_steps):
#       # TODO: define, and justify from theory, how Psi_n enters the
#       # torsion integral / Phi(S) / B(H) computation at step n+1.
#       # This coupling is NOT specified anywhere in the current theoretical
#       # framework -- it must be derived, not guessed.
#       psi = ...  # placeholder -- do NOT fill this with an arbitrary formula
#       history.append(psi)
#
# Until that coupling is derived and justified, no "temporal evolution",
# "asymptotic convergence", or "residual" figures should be reported, and
# none are computed in this notebook.


# ## 8. Sensitivity check on the normalization constant
# 
# This addresses the weakness flagged in paper Section 7 ("why α specifically?"). We recompute Ψ_L using alternative dimensionless constants in place of α, to check whether α plays any qualitatively special role, or behaves as a generic linear scale factor.

# In[18]:


def sensitivity_check(df, phi_s):
    """Recompute Psi_L with alternative dimensionless normalization constants
    in place of alpha, to check whether alpha plays any qualitatively special
    role or whether it behaves as a generic scale factor.

    This does NOT prove alpha is the "correct" constant -- it only tests
    whether swapping it for other well-known dimensionless numbers changes
    the qualitative behaviour of Psi_L (it should not, if alpha is acting
    purely as a numerical normalization rather than encoding real physics).
    """
    candidates = {
        "alpha (1/137.036)": ALPHA,
        "1/(2*pi)": 1 / (2 * np.pi),
        "inverse golden ratio (1/phi)": 2 / (1 + np.sqrt(5)),
        "arbitrary control (0.01)": 0.01,
    }

    b_h = dissipation_B()

    print(f"{'Constant':30s} {'value':>12s} {'Psi_L (real)':>16s} {'Psi_L (imag)':>16s}")
    for label, value in candidates.items():
        integral_value = torsion_integral(df, alpha=value)
        psi_l = phi_s * integral_value - b_h
        print(f"{label:30s} {value:12.6f} {psi_l.real:16.6e} {psi_l.imag:16.6e}")

sensitivity_check(df_clean, phi_s)


# > **Interpretation:** if Ψ_L scales roughly linearly with the constant used (as expected from the formula's algebra, since α enters as a linear multiplicative factor in the torsion integral), this confirms α is acting here as a numerical normalization choice, not as evidence of a specific physical role for the fine-structure constant. This test does not resolve the "why α" question — it only shows the construction does not depend on it in a special way beyond linear scaling. See paper Section 7.

# In[ ]:




